#!/bin/bash
echo "Stopping OpenMRS..."
docker-compose down